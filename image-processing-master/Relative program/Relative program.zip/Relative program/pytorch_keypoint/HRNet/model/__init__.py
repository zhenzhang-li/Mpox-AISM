from .hrnet import HighResolutionNet
