## download mini-imagenet
link: [https://pan.baidu.com/s/1Uro6RuEbRGGCQ8iXvF2SAQ](https://pan.baidu.com/s/1Uro6RuEbRGGCQ8iXvF2SAQ)  password: hl31

## dataset path structure
```
├── mini-imagenet: total 100 classes, 60000 images
     ├── images: 60000 images
     ├── train.csv: 64 classes, 38400 images
     ├── val.csv: 16 classes, 9600 images
     └── test.csv: 20 classes, 12000 images
```